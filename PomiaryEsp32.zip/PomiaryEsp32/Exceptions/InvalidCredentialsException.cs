﻿namespace PomiaryEsp32.Exceptions
{
    public class InvalidCredentialsException : Exception
    {
        public InvalidCredentialsException() : base("Invalid credentials")
        {

        }
    }
}
